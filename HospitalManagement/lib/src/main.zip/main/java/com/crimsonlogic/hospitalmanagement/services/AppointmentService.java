package com.crimsonlogic.hospitalmanagement.services;

import java.time.LocalDate;
import java.util.List;

import org.apache.ibatis.session.SqlSession;

import com.crimsonlogic.hospitalmanagement.exceptions.AppointmentNotFoundException;
import com.crimsonlogic.hospitalmanagement.mapper.AppointmentMapper;
import com.crimsonlogic.hospitalmanagement.model.Appointment;
import com.crimsonlogic.hospitalmanagement.util.MyBatisUtil;

public class AppointmentService {

    public void addAppointment(Appointment appointment) {

        validateAppointment(appointment);

        try (SqlSession session = MyBatisUtil.getSqlSession()) {

            AppointmentMapper mapper =
                    session.getMapper(AppointmentMapper.class);

            mapper.addAppointment(appointment);

            session.commit();
        }
    }

    public Appointment getAppointmentById(int appointmentId) {

        try (SqlSession session = MyBatisUtil.getSqlSession()) {

            AppointmentMapper mapper =
                    session.getMapper(AppointmentMapper.class);

            Appointment appointment =
                    mapper.getAppointmentById(appointmentId);

            if (appointment == null) {

                throw new AppointmentNotFoundException(
                        "Appointment with ID "
                        + appointmentId
                        + " not found");
            }

            return appointment;
        }
    }

    public List<Appointment> getAllAppointments() {

        try (SqlSession session = MyBatisUtil.getSqlSession()) {

            AppointmentMapper mapper =
                    session.getMapper(AppointmentMapper.class);

            return mapper.getAllAppointments();
        }
    }

    public void updateAppointment(Appointment appointment) {

        validateAppointment(appointment);

        try (SqlSession session = MyBatisUtil.getSqlSession()) {

            AppointmentMapper mapper =
                    session.getMapper(AppointmentMapper.class);

            Appointment existingAppointment =
                    mapper.getAppointmentById(
                            appointment.getAppointmentId());

            if (existingAppointment == null) {

                throw new AppointmentNotFoundException(
                        "Appointment with ID "
                        + appointment.getAppointmentId()
                        + " not found");
            }

            mapper.updateAppointment(appointment);

            session.commit();
        }
    }

    public void deleteAppointment(int appointmentId) {

        try (SqlSession session = MyBatisUtil.getSqlSession()) {

            AppointmentMapper mapper =
                    session.getMapper(AppointmentMapper.class);

            Appointment appointment =
                    mapper.getAppointmentById(appointmentId);

            if (appointment == null) {

                throw new AppointmentNotFoundException(
                        "Appointment with ID "
                        + appointmentId
                        + " not found");
            }

            mapper.deleteAppointment(appointmentId);

            session.commit();
        }
    }

    private void validateAppointment(
            Appointment appointment) {

        if (appointment == null) {

            throw new IllegalArgumentException(
                    "Appointment cannot be null");
        }

        if (appointment.getAppointmentDate() == null) {

            throw new IllegalArgumentException(
                    "Appointment date cannot be null");
        }

        if (appointment.getAppointmentDate()
                .isBefore(LocalDate.now())) {

            throw new IllegalArgumentException(
                    "Appointment date cannot be in the past");
        }

        if (appointment.getAppointmentTime() == null) {

            throw new IllegalArgumentException(
                    "Appointment time cannot be null");
        }

        if (appointment.getPatient() == null) {

            throw new IllegalArgumentException(
                    "Patient cannot be null");
        }

        if (appointment.getDoctor() == null) {

            throw new IllegalArgumentException(
                    "Doctor cannot be null");
        }
    }
}