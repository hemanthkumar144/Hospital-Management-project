package com.crimsonlogic.hospitalmanagement.mapper;

import java.util.List;

import com.crimsonlogic.hospitalmanagement.model.Patient;

public interface PatientMapper {

    void addPatient(Patient patient);

    Patient getPatientById(String patientId);

    List<Patient> getAllPatients();

    void updatePatient(Patient patient);

    void deletePatient(String patientId);
    Integer getMaxPatientNumber();
}