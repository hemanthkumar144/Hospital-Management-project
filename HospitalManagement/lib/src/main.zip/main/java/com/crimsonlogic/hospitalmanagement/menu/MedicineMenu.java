package com.crimsonlogic.hospitalmanagement.menu;

import java.util.List;
import java.util.Scanner;

import com.crimsonlogic.hospitalmanagement.model.Medicine;
import com.crimsonlogic.hospitalmanagement.services.MedicineService;

public class MedicineMenu {

    public static void showMenu(Scanner sc) {

        MedicineService service = new MedicineService();

        while (true) {

            System.out.println("\n========== MEDICINE MANAGEMENT ==========");
            System.out.println("1. Add Medicine");
            System.out.println("2. View Medicine By ID");
            System.out.println("3. View All Medicines");
            System.out.println("4. Update Medicine");
            System.out.println("5. Delete Medicine");
            System.out.println("6. Back");

            System.out.print("Enter Choice : ");
            int choice = sc.nextInt();

            switch (choice) {

                case 1:

                    System.out.print("Medicine ID : ");
                    int medicineId = sc.nextInt();
                    sc.nextLine();

                    System.out.print("Medicine Name : ");
                    String medicineName = sc.nextLine();

                    System.out.print("Manufacturer : ");
                    String manufacturer = sc.nextLine();

                    System.out.print("Price : ");
                    double price = sc.nextDouble();

                    Medicine medicine = new Medicine(
                            medicineId,
                            medicineName,
                            manufacturer,
                            price);

                    service.addMedicine(medicine);

                    System.out.println("Medicine Added Successfully");
                    break;

                case 2:

                    System.out.print("Enter Medicine ID : ");
                    int id = sc.nextInt();

                    Medicine m = service.getMedicineById(id);

                    if (m != null)
                        System.out.println(m);
                    else
                        System.out.println("Medicine Not Found");

                    break;

                case 3:

                    List<Medicine> medicines = service.getAllMedicines();

                    System.out.printf("%-12s %-25s %-20s %-10s%n",
                            "Medicine ID",
                            "Medicine Name",
                            "Manufacturer",
                            "Price");

                    System.out.println("------------------------------------------------------------------");

                    for (Medicine med : medicines) {

                        System.out.printf("%-12d %-25s %-20s %-10.2f%n",
                                med.getMedicineId(),
                                med.getMedicineName(),
                                med.getManufacturer(),
                                med.getPrice());
                    }

                    break;

                case 4:

                    System.out.print("Medicine ID : ");
                    int updateId = sc.nextInt();
                    sc.nextLine();

                    System.out.print("Medicine Name : ");
                    String updateName = sc.nextLine();

                    System.out.print("Manufacturer : ");
                    String updateManufacturer = sc.nextLine();

                    System.out.print("Price : ");
                    double updatePrice = sc.nextDouble();

                    Medicine updateMedicine = new Medicine(
                            updateId,
                            updateName,
                            updateManufacturer,
                            updatePrice);

                    service.updateMedicine(updateMedicine);

                    System.out.println("Medicine Updated Successfully");
                    break;

                case 5:

                    System.out.print("Enter Medicine ID : ");
                    int deleteId = sc.nextInt();

                    service.deleteMedicine(deleteId);

                    System.out.println("Medicine Deleted Successfully");
                    break;

                case 6:
                    return;

                default:
                    System.out.println("Invalid Choice");
            }
        }
    }
}