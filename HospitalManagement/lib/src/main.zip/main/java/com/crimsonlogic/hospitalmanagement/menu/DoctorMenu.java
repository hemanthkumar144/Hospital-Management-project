package com.crimsonlogic.hospitalmanagement.menu;

import java.util.List;
import java.util.Scanner;

import com.crimsonlogic.hospitalmanagement.model.Department;
import com.crimsonlogic.hospitalmanagement.model.Doctor;
import com.crimsonlogic.hospitalmanagement.services.DoctorService;

public class DoctorMenu {

    public static void showMenu(Scanner sc) {

        DoctorService service = new DoctorService();

        while (true) {

            System.out.println("\n========== DOCTOR MANAGEMENT ==========");
            System.out.println("1. Add Doctor");
            System.out.println("2. View Doctor By ID");
            System.out.println("3. View All Doctors");
            System.out.println("4. Update Doctor");
            System.out.println("5. Delete Doctor");
            System.out.println("6. Back");

            System.out.print("Enter Choice : ");
            int choice = sc.nextInt();

            switch (choice) {

                case 1:
                	
                        System.out.print("Staff Name : ");
                        String staffName = sc.nextLine();

                        int age;

                        while (true) {

                            try {

                                System.out.print("Age : ");
                                age = Integer.parseInt(sc.nextLine());

                                if (age < 1 || age > 120) {

                                    System.out.println(
                                            "Age should be between 1 and 120");
                                    continue;
                                }

                                break;

                            } catch (NumberFormatException e) {

                                System.out.println(
                                        "Please enter a valid age.");
                            }
                        }

                        System.out.print("Gender : ");
                        String gender = sc.nextLine();

                        System.out.print("Phone : ");
                        String phone = sc.nextLine();

                        double salary;

                        while (true) {

                            try {

                                System.out.print("Salary : ");
                                salary = sc.nextDouble();

                                if (salary <= 0) {

                                    System.out.println(
                                            "Salary must be greater than zero.");
                                    continue;
                                }

                                break;

                            } catch (NumberFormatException e) {

                                System.out.println(
                                        "Please enter a valid salary.");
                            }
                        }

                        System.out.print("Specialization : ");
                        String specialization = sc.next();

                        int experience;

                        while (true) {

                            try {

                                System.out.print("Experience : ");
                                experience = sc.nextInt();

                                if (experience < 0) {

                                    System.out.println(
                                            "Experience cannot be negative.");
                                    continue;
                                }

                                break;

                            } catch (NumberFormatException e) {

                                System.out.println(
                                        "Please enter a valid experience.");
                            }
                        }

                        String departmentId;

                        

                        Department department = new Department();
                        department.setDepartmentId(departmentId);

                        Doctor doctor = new Doctor(
                                staffId,
                                staffName,
                                age,
                                gender,
                                phone,
                                salary,
                                specialization,
                                experience,
                                department);

                        service.addDoctor(doctor);

                        System.out.println(
                                "Doctor Added Successfully");

                    } catch (Exception e) {

                        System.out.println(
                                "Error : " + e.getMessage());
                    }

                    break;

                case 2:

                    try {

                        int id;

                        while (true) {

                            try {

                                System.out.print(
                                        "Enter Staff ID : ");

                                id = Integer.parseInt(
                                        sc.nextLine());

                                if (id <= 0) {

                                    System.out.println(
                                            "ID must be positive.");
                                    continue;
                                }

                                break;

                            } catch (NumberFormatException e) {

                                System.out.println(
                                        "Please enter a valid ID.");
                            }
                        }

                        Doctor d =
                                service.getDoctorById(id);

                        System.out.println(
                                "\nDoctor Details");

                        System.out.println(
                                "-------------------------");

                        System.out.println(
                                "ID : "
                                + d.getStaffId());

                        System.out.println(
                                "Name : "
                                + d.getStaffName());

                        System.out.println(
                                "Age : "
                                + d.getAge());

                        System.out.println(
                                "Gender : "
                                + d.getGender());

                        System.out.println(
                                "Phone : "
                                + d.getPhone());

                        System.out.println(
                                "Salary : "
                                + d.getSalary());

                        System.out.println(
                                "Specialization : "
                                + d.getSpecialization());

                        System.out.println(
                                "Experience : "
                                + d.getExperience());

                        System.out.println(
                                "Department : "
                                + d.getDepartment()
                                        .getDepartmentName());

                    } catch (Exception e) {

                        System.out.println(
                                "Error : "
                                + e.getMessage());
                    }

                    break;
                case 3:

                    List<Doctor> doctors = service.getAllDoctors();

                    System.out.printf(
                            "%-8s %-20s %-5s %-10s %-15s %-12s %-10s%n",
                            "ID",
                            "Name",
                            "Age",
                            "Gender",
                            "Phone",
                            "Specialization",
                            "Dept");

                    System.out.println(
                            "---------------------------------------------------------------------------------------");

                    for (Doctor doc : doctors) {

                        System.out.printf(
                                "%-8d %-20s %-5d %-10s %-15s %-12s %-10s%n",
                                doc.getStaffId(),
                                doc.getStaffName(),
                                doc.getAge(),
                                doc.getGender(),
                                doc.getPhone(),
                                doc.getSpecialization(),
                                doc.getDepartment().getDepartmentName());
                    }

                    break;

                case 4:

                    try {

                        int updateId;

                        while (true) {

                            try {

                                System.out.print("Staff ID : ");

                                updateId = Integer.parseInt(
                                        sc.nextLine());

                                if (updateId <= 0) {

                                    System.out.println(
                                            "Staff ID must be positive.");
                                    continue;
                                }

                                break;

                            } catch (NumberFormatException e) {

                                System.out.println(
                                        "Please enter a valid Staff ID.");
                            }
                        }

                        System.out.print("Staff Name : ");
                        String updateName = sc.nextLine();

                        int updateAge;

                        while (true) {

                            try {

                                System.out.print("Age : ");

                                updateAge = Integer.parseInt(
                                        sc.nextLine());

                                if (updateAge < 1 ||
                                        updateAge > 120) {

                                    System.out.println(
                                            "Age should be between 1 and 120");
                                    continue;
                                }

                                break;

                            } catch (NumberFormatException e) {

                                System.out.println(
                                        "Please enter a valid age.");
                            }
                        }

                        System.out.print("Gender : ");
                        String updateGender = sc.nextLine();

                        System.out.print("Phone : ");
                        String updatePhone = sc.nextLine();

                        double updateSalary;

                        while (true) {

                            try {

                                System.out.print("Salary : ");

                                updateSalary = Double.parseDouble(
                                        sc.nextLine());

                                if (updateSalary <= 0) {

                                    System.out.println(
                                            "Salary must be greater than zero.");
                                    continue;
                                }

                                break;

                            } catch (NumberFormatException e) {

                                System.out.println(
                                        "Please enter a valid salary.");
                            }
                        }

                        System.out.print("Specialization : ");
                        String updateSpecialization =
                                sc.nextLine();

                        int updateExperience;

                        while (true) {

                            try {

                                System.out.print("Experience : ");

                                updateExperience =
                                        Integer.parseInt(
                                                sc.nextLine());

                                if (updateExperience < 0) {

                                    System.out.println(
                                            "Experience cannot be negative.");
                                    continue;
                                }

                                break;

                            } catch (NumberFormatException e) {

                                System.out.println(
                                        "Please enter a valid experience.");
                            }
                        }

                        int updateDeptId;

                        while (true) {

                            try {

                                System.out.print(
                                        "Department ID : ");

                                updateDeptId =
                                        Integer.parseInt(
                                                sc.nextLine());

                                if (updateDeptId <= 0) {

                                    System.out.println(
                                            "Department ID must be positive.");
                                    continue;
                                }

                                break;

                            } catch (NumberFormatException e) {

                                System.out.println(
                                        "Please enter a valid Department ID.");
                            }
                        }

                        Department updateDepartment =
                                new Department();

                        updateDepartment.setDepartmentId(
                                updateDeptId);

                        Doctor updateDoctor =
                                new Doctor(
                                        updateId,
                                        updateName,
                                        updateAge,
                                        updateGender,
                                        updatePhone,
                                        updateSalary,
                                        updateSpecialization,
                                        updateExperience,
                                        updateDepartment);

                        service.updateDoctor(
                                updateDoctor);

                        System.out.println(
                                "Doctor Updated Successfully");

                    } catch (Exception e) {

                        System.out.println(
                                "Error : "
                                + e.getMessage());
                    }

                    break;

                case 5:

                    try {

                        int deleteId;

                        while (true) {

                            try {

                                System.out.print(
                                        "Enter Staff ID : ");

                                deleteId = Integer.parseInt(
                                        sc.nextLine());

                                if (deleteId <= 0) {

                                    System.out.println(
                                            "ID must be positive.");
                                    continue;
                                }

                                break;

                            } catch (NumberFormatException e) {

                                System.out.println(
                                        "Please enter a valid ID.");
                            }
                        }

                        service.deleteDoctor(deleteId);

                        System.out.println(
                                "Doctor Deleted Successfully");

                    } catch (Exception e) {

                        System.out.println(
                                "Error : "
                                + e.getMessage());
                    }

                    break;
                case 6:
                    return;

                default:
                    System.out.println("Invalid Choice");
            }
        }
    }
}