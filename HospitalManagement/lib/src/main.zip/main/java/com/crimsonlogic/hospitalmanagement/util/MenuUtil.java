package com.crimsonlogic.hospitalmanagement.util;

import java.util.List;
import java.util.Scanner;

import com.crimsonlogic.hospitalmanagement.model.Department;
import com.crimsonlogic.hospitalmanagement.services.DepartmentService;

public class MenuUtil {

    private static Scanner sc = new Scanner(System.in);
    private static DepartmentService service = new DepartmentService();

    public static void departmentMenu() {

        int choice;

        do {

            System.out.println("\n===== DEPARTMENT MENU =====");
            System.out.println("1. Add Department");
            System.out.println("2. Get Department By Id");
            System.out.println("3. Get All Departments");
            System.out.println("4. Update Department");
            System.out.println("5. Delete Department");
            System.out.println("0. Exit");
            System.out.print("Enter Choice : ");

            choice = sc.nextInt();

            switch (choice) {

                case 1:

                    Department department = new Department();

                    System.out.print("Department Id : ");
                    department.setDepartmentId(sc.nextInt());

                    sc.nextLine();

                    System.out.print("Department Name : ");
                    department.setDepartmentName(sc.nextLine());

                    System.out.print("Location : ");
                    department.setLocation(sc.nextLine());

                    service.addDepartment(department);

                    System.out.println("Department Added Successfully");
                    break;

                case 2:

                    System.out.print("Enter Department Id : ");
                    int id = sc.nextInt();

                    System.out.println(service.getDepartmentById(id));

                    break;

                case 3:

                	List<Department> departments =
                    service.getAllDepartments();

            System.out.println("------------------------------------------------------");
            System.out.printf("%-15s %-20s %-15s%n",
                    "Department ID",
                    "Department Name",
                    "Location");
            System.out.println("------------------------------------------------------");

            for (Department d : departments) {

                System.out.printf("%-15d %-20s %-15s%n",
                        d.getDepartmentId(),
                        d.getDepartmentName(),
                        d.getLocation());
            }

            System.out.println("------------------------------------------------------");

                    break;

                case 4:

                    Department updateDept = new Department();

                    System.out.print("Department Id : ");
                    updateDept.setDepartmentId(sc.nextInt());

                    sc.nextLine();

                    System.out.print("New Department Name : ");
                    updateDept.setDepartmentName(sc.nextLine());

                    System.out.print("New Location : ");
                    updateDept.setLocation(sc.nextLine());

                    service.updateDepartment(updateDept);

                    System.out.println("Department Updated Successfully");

                    break;

                case 5:

                    System.out.print("Department Id : ");
                    int deleteId = sc.nextInt();

                    service.deleteDepartment(deleteId);

                    System.out.println("Department Deleted Successfully");

                    break;

                case 0:

                    System.out.println("Returning...");
                    break;

                default:

                    System.out.println("Invalid Choice");
            }

        } while (choice != 0);
    }
}