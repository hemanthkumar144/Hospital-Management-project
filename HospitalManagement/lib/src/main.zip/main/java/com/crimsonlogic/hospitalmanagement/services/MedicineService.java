package com.crimsonlogic.hospitalmanagement.services;

import java.util.List;

import org.apache.ibatis.session.SqlSession;

import com.crimsonlogic.hospitalmanagement.exceptions.MedicineNotFoundException;
import com.crimsonlogic.hospitalmanagement.mapper.MedicineMapper;
import com.crimsonlogic.hospitalmanagement.model.Medicine;
import com.crimsonlogic.hospitalmanagement.util.MyBatisUtil;

public class MedicineService {

    public void addMedicine(Medicine medicine) {

        validateMedicine(medicine);

        try (SqlSession session = MyBatisUtil.getSqlSession()) {

            MedicineMapper mapper =
                    session.getMapper(MedicineMapper.class);

            mapper.addMedicine(medicine);

            session.commit();
        }
    }

    public Medicine getMedicineById(int medicineId) {

        try (SqlSession session = MyBatisUtil.getSqlSession()) {

            MedicineMapper mapper =
                    session.getMapper(MedicineMapper.class);

            Medicine medicine =
                    mapper.getMedicineById(medicineId);

            if (medicine == null) {

                throw new MedicineNotFoundException(
                        "Medicine with ID "
                        + medicineId
                        + " not found");
            }

            return medicine;
        }
    }

    public List<Medicine> getAllMedicines() {

        try (SqlSession session = MyBatisUtil.getSqlSession()) {

            MedicineMapper mapper =
                    session.getMapper(MedicineMapper.class);

            return mapper.getAllMedicines();
        }
    }

    public void updateMedicine(Medicine medicine) {

        validateMedicine(medicine);

        try (SqlSession session = MyBatisUtil.getSqlSession()) {

            MedicineMapper mapper =
                    session.getMapper(MedicineMapper.class);

            Medicine existingMedicine =
                    mapper.getMedicineById(
                            medicine.getMedicineId());

            if (existingMedicine == null) {

                throw new MedicineNotFoundException(
                        "Medicine with ID "
                        + medicine.getMedicineId()
                        + " not found");
            }

            mapper.updateMedicine(medicine);

            session.commit();
        }
    }

    public void deleteMedicine(int medicineId) {

        try (SqlSession session = MyBatisUtil.getSqlSession()) {

            MedicineMapper mapper =
                    session.getMapper(MedicineMapper.class);

            Medicine medicine =
                    mapper.getMedicineById(medicineId);

            if (medicine == null) {

                throw new MedicineNotFoundException(
                        "Medicine with ID "
                        + medicineId
                        + " not found");
            }

            mapper.deleteMedicine(medicineId);

            session.commit();
        }
    }

    private void validateMedicine(Medicine medicine) {

        if (medicine == null) {

            throw new IllegalArgumentException(
                    "Medicine cannot be null");
        }

        if (medicine.getMedicineName() == null ||
                medicine.getMedicineName().trim().isEmpty()) {

            throw new IllegalArgumentException(
                    "Medicine name cannot be empty");
        }

        if (!medicine.getMedicineName()
                .matches("^[A-Za-z0-9 ]{2,50}$")) {

            throw new IllegalArgumentException(
                    "Medicine name should contain only letters, numbers and spaces");
        }

        if (medicine.getManufacturer() == null ||
                medicine.getManufacturer().trim().isEmpty()) {

            throw new IllegalArgumentException(
                    "Manufacturer cannot be empty");
        }

        if (!medicine.getManufacturer()
                .matches("^[A-Za-z0-9 ]{2,50}$")) {

            throw new IllegalArgumentException(
                    "Manufacturer should contain only letters, numbers and spaces");
        }

        if (medicine.getPrice() <= 0) {

            throw new IllegalArgumentException(
                    "Price must be greater than zero");
        }
    }
}