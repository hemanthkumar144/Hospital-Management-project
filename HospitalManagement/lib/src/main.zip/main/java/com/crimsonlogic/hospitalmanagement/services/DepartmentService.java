package com.crimsonlogic.hospitalmanagement.services;

import java.util.List;

import org.apache.ibatis.session.SqlSession;

import com.crimsonlogic.hospitalmanagement.exceptions.DepartmentNotFoundException;
import com.crimsonlogic.hospitalmanagement.mapper.DepartmentMapper;
import com.crimsonlogic.hospitalmanagement.model.Department;
import com.crimsonlogic.hospitalmanagement.util.MyBatisUtil;

public class DepartmentService {

    public void addDepartment(Department department) {

        validateDepartment(department);

        try (SqlSession session = MyBatisUtil.getSqlSession()) {

            DepartmentMapper mapper =
                    session.getMapper(DepartmentMapper.class);

            mapper.addDepartment(department);

            session.commit();
        }
    }

    public Department getDepartmentById(int departmentId) {

        try (SqlSession session = MyBatisUtil.getSqlSession()) {

            DepartmentMapper mapper =
                    session.getMapper(DepartmentMapper.class);

            Department department =
                    mapper.getDepartmentById(departmentId);

            if (department == null) {

                throw new DepartmentNotFoundException(
                        "Department with ID "
                        + departmentId
                        + " not found");
            }

            return department;
        }
    }

    public List<Department> getAllDepartments() {

        try (SqlSession session = MyBatisUtil.getSqlSession()) {

            DepartmentMapper mapper =
                    session.getMapper(DepartmentMapper.class);

            return mapper.getAllDepartments();
        }
    }

    public void updateDepartment(Department department) {

        validateDepartment(department);

        try (SqlSession session = MyBatisUtil.getSqlSession()) {

            DepartmentMapper mapper =
                    session.getMapper(DepartmentMapper.class);

            Department existingDepartment =
                    mapper.getDepartmentById(
                            department.getDepartmentId());

            if (existingDepartment == null) {

                throw new DepartmentNotFoundException(
                        "Department with ID "
                        + department.getDepartmentId()
                        + " not found");
            }

            mapper.updateDepartment(department);

            session.commit();
        }
    }

    public void deleteDepartment(int departmentId) {

        try (SqlSession session = MyBatisUtil.getSqlSession()) {

            DepartmentMapper mapper =
                    session.getMapper(DepartmentMapper.class);

            Department department =
                    mapper.getDepartmentById(departmentId);

            if (department == null) {

                throw new DepartmentNotFoundException(
                        "Department with ID "
                        + departmentId
                        + " not found");
            }

            mapper.deleteDepartment(departmentId);

            session.commit();
        }
    }

    private void validateDepartment(Department department) {
    	
    	
        if (department == null) {

            throw new IllegalArgumentException(
                    "Department cannot be null");
        }

        if (department.getDepartmentName() == null ||
                department.getDepartmentName().trim().isEmpty()) {

            throw new IllegalArgumentException(
                    "Department name cannot be empty");
        }

        if (!department.getDepartmentName()
                .matches("^[A-Za-z ]{2,50}$")) {

            throw new IllegalArgumentException(
                    "Department name should contain only alphabets and spaces");
        }

        if (department.getLocation() == null ||
                department.getLocation().trim().isEmpty()) {

            throw new IllegalArgumentException(
                    "Location cannot be empty");
        }

        if (!department.getLocation()
                .matches("^[A-Za-z ]{2,50}$")) {

            throw new IllegalArgumentException(
                    "Location should contain only alphabets and spaces");
        }
    }
}