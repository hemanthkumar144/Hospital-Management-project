package com.crimsonlogic.hospitalmanagement.menu;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.List;
import java.util.Scanner;

import com.crimsonlogic.hospitalmanagement.model.Appointment;
import com.crimsonlogic.hospitalmanagement.model.Doctor;
import com.crimsonlogic.hospitalmanagement.model.Patient;
import com.crimsonlogic.hospitalmanagement.services.AppointmentService;

public class AppointmentMenu {

    public static void showMenu(Scanner sc) {

        AppointmentService service = new AppointmentService();

        while (true) {

            System.out.println("\n========== APPOINTMENT MANAGEMENT ==========");
            System.out.println("1. Add Appointment");
            System.out.println("2. View Appointment By ID");
            System.out.println("3. View All Appointments");
            System.out.println("4. Update Appointment");
            System.out.println("5. Delete Appointment");
            System.out.println("6. Back");

            System.out.print("Enter Choice : ");
            int choice = sc.nextInt();

            switch (choice) {

                case 1:

                    System.out.print("Appointment ID : ");
                    String appointmentId = sc.next();
                    sc.nextLine();

                    System.out.print("Appointment Date (yyyy-mm-dd) : ");
                    LocalDate date =
                            LocalDate.parse(sc.nextLine());

                    System.out.print("Appointment Time (HH:mm) : ");
                    LocalTime time =
                            LocalTime.parse(sc.nextLine());

                    System.out.print("Patient ID : ");
                    String patientId = sc.next();

                    System.out.print("Doctor ID : ");
                    String doctorId = sc.next();

                    Patient patient = new Patient();
                    patient.setPatientId(patientId);

                    Doctor doctor = new Doctor();
                    doctor.setStaffId(doctorId);

                    Appointment appointment =
                            new Appointment(
                                    appointmentId,
                                    date,
                                    time,
                                    patient,
                                    doctor);

                    service.addAppointment(appointment);

                    System.out.println("Appointment Added Successfully");
                    break;

                case 2:

                    System.out.print("Enter Appointment ID : ");
                    int id = sc.nextInt();

                    Appointment a =
                            service.getAppointmentById(id);

                    if (a != null)
                        System.out.println(a);
                    else
                        System.out.println("Appointment Not Found");

                    break;

                case 3:

                    List<Appointment> appointments =
                            service.getAllAppointments();

                    System.out.printf(
                            "%-10s %-15s %-10s %-12s %-15s %-10s %-15s%n",
                            "App ID",
                            "Date",
                            "Time",
                            "Patient ID",
                            "Patient Name",
                            "Doctor ID",
                            "Doctor Name");

                    System.out.println(
                            "---------------------------------------------------------------------------------------------");

                    for (Appointment app : appointments) {

                        System.out.printf(
                                "%-10d %-15s %-10s %-12d %-15s %-10d %-15s%n",
                                app.getAppointmentId(),
                                app.getAppointmentDate(),
                                app.getAppointmentTime(),
                                app.getPatient().getPatientId(),
                                app.getPatient().getPatientName(),
                                app.getDoctor().getStaffId(),
                                app.getDoctor().getStaffName());
                    }

                    break;

                case 4:

                    System.out.print("Appointment ID : ");
                    String updateId = sc.next();
                    sc.nextLine();

                    System.out.print("Appointment Date (yyyy-mm-dd) : ");
                    LocalDate updateDate =
                            LocalDate.parse(sc.nextLine());

                    System.out.print("Appointment Time (HH:mm) : ");
                    LocalTime updateTime =
                            LocalTime.parse(sc.nextLine());

                    System.out.print("Patient ID : ");
                    String updatePatientId = sc.next();

                    System.out.print("Doctor ID : ");
                    String updateDoctorId = sc.next();

                    Patient updatePatient = new Patient();
                    updatePatient.setPatientId(updatePatientId);

                    Doctor updateDoctor = new Doctor();
                    updateDoctor.setStaffId(updateDoctorId);

                    Appointment updateAppointment =
                            new Appointment(
                                    updateId,
                                    updateDate,
                                    updateTime,
                                    updatePatient,
                                    updateDoctor);

                    service.updateAppointment(updateAppointment);

                    System.out.println("Appointment Updated Successfully");
                    break;

                case 5:

                    System.out.print("Enter Appointment ID : ");
                    int deleteId = sc.nextInt();

                    service.deleteAppointment(deleteId);

                    System.out.println("Appointment Deleted Successfully");
                    break;

                case 6:
                    return;

                default:
                    System.out.println("Invalid Choice");
            }
        }
    }
}