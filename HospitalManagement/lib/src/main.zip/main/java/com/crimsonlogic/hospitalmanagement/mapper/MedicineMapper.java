package com.crimsonlogic.hospitalmanagement.mapper;

import java.util.List;

import com.crimsonlogic.hospitalmanagement.model.Medicine;

public interface MedicineMapper {

    void addMedicine(Medicine medicine);

    Medicine getMedicineById(String medicineId);

    List<Medicine> getAllMedicines();

    void updateMedicine(Medicine medicine);

    void deleteMedicine(String medicineId);
    Integer getMaxMedicineNumber();
}
