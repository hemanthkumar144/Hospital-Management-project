package com.crimsonlogic.hospitalmanagement.menu;

import java.util.List;
import java.util.Scanner;

import com.crimsonlogic.hospitalmanagement.model.Address;
import com.crimsonlogic.hospitalmanagement.model.Patient;
import com.crimsonlogic.hospitalmanagement.services.PatientService;

public class PatientMenu {

    public static void showMenu(Scanner sc) {

        PatientService service = new PatientService();

        while (true) {

            System.out.println("\n========== PATIENT MANAGEMENT ==========");
            System.out.println("1. Add Patient");
            System.out.println("2. View Patient By ID");
            System.out.println("3. View All Patients");
            System.out.println("4. Update Patient");
            System.out.println("5. Delete Patient");
            System.out.println("6. Back");

            System.out.print("Enter Choice : ");
            int choice = sc.nextInt();

            switch (choice) {

                case 1:

                    System.out.print("Patient ID : ");
                    int patientId = sc.nextInt();
                    sc.nextLine();

                    System.out.print("Patient Name : ");
                    String patientName = sc.nextLine();

                    System.out.print("Age : ");
                    int age = sc.nextInt();
                    sc.nextLine();

                    System.out.print("Gender : ");
                    String gender = sc.nextLine();

                    System.out.print("Phone : ");
                    String phone = sc.nextLine();

                    System.out.print("Address ID : ");
                    int addressId = sc.nextInt();

                    Address address = new Address();
                    address.setAddressId(addressId);

                    Patient patient = new Patient(
                            patientId,
                            patientName,
                            age,
                            gender,
                            phone,
                            address);

                    service.addPatient(patient);

                    System.out.println("Patient Added Successfully");
                    break;

                case 2:

                    System.out.print("Enter Patient ID : ");
                    int id = sc.nextInt();

                    Patient p = service.getPatientById(id);

                    if (p != null)
                        System.out.println(p);
                    else
                        System.out.println("Patient Not Found");

                    break;

                case 3:

                    List<Patient> patients = service.getAllPatients();

                    System.out.printf(
                            "%-10s %-20s %-5s %-10s %-15s %-15s%n",
                            "ID",
                            "Name",
                            "Age",
                            "Gender",
                            "Phone",
                            "City");

                    System.out.println(
                            "--------------------------------------------------------------------------------");

                    for (Patient pat : patients) {

                        System.out.printf(
                                "%-10d %-20s %-5d %-10s %-15s %-15s%n",
                                pat.getPatientId(),
                                pat.getPatientName(),
                                pat.getAge(),
                                pat.getGender(),
                                pat.getPhone(),
                                pat.getAddress().getCity());
                    }

                    break;

                case 4:

                    System.out.print("Patient ID : ");
                    int updateId = sc.nextInt();
                    sc.nextLine();

                    System.out.print("Patient Name : ");
                    String updateName = sc.nextLine();

                    System.out.print("Age : ");
                    int updateAge = sc.nextInt();
                    sc.nextLine();

                    System.out.print("Gender : ");
                    String updateGender = sc.nextLine();

                    System.out.print("Phone : ");
                    String updatePhone = sc.nextLine();

                    System.out.print("Address ID : ");
                    int updateAddressId = sc.nextInt();

                    Address updateAddress = new Address();
                    updateAddress.setAddressId(updateAddressId);

                    Patient updatePatient = new Patient(
                            updateId,
                            updateName,
                            updateAge,
                            updateGender,
                            updatePhone,
                            updateAddress);

                    service.updatePatient(updatePatient);

                    System.out.println("Patient Updated Successfully");
                    break;

                case 5:

                    System.out.print("Enter Patient ID : ");
                    int deleteId = sc.nextInt();

                    service.deletePatient(deleteId);

                    System.out.println("Patient Deleted Successfully");
                    break;

                case 6:
                    return;

                default:
                    System.out.println("Invalid Choice");
            }
        }
    }
}