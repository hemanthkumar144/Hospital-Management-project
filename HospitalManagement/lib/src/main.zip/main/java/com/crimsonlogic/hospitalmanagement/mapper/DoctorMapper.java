package com.crimsonlogic.hospitalmanagement.mapper;


import java.util.List;
import com.crimsonlogic.hospitalmanagement.model.Doctor;

public interface DoctorMapper {

    void addDoctor(Doctor doctor);

    Doctor getDoctorById(String staffId);

    void deleteDoctor(String staffId);

    List<Doctor> getAllDoctors();

    void updateDoctor(Doctor doctor);
    Integer getMaxDoctorNumber();
}