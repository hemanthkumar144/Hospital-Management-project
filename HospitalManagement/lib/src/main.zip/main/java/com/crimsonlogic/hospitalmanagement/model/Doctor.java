package com.crimsonlogic.hospitalmanagement.model;

public class Doctor {

	private String staffId;
    private String staffName;
    private int age;
    private String gender;
    private String phone;
    private double salary;
    private String specialization;
    private int experience;
    private Department department;

    public Doctor() {}

    public Doctor(String staffId, String staffName, int age, String gender,
                  String phone, double salary, String specialization,
                  int experience, Department department) {
        this.staffId = staffId;
        this.staffName = staffName;
        this.age = age;
        this.gender = gender;
        this.phone = phone;
        this.salary = salary;
        this.specialization = specialization;
        this.experience = experience;
        this.department = department;
    }

    

    public String getStaffId() {
		return staffId;
	}

	public void setStaffId(String staffId) {
		this.staffId = staffId;
	}

	public String getStaffName() {
        return staffName;
    }

    public void setStaffName(String staffName) {
        this.staffName = staffName;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public double getSalary() {
        return salary;
    }

    public void setSalary(double salary) {
        this.salary = salary;
    }

    public String getSpecialization() {
        return specialization;
    }

    public void setSpecialization(String specialization) {
        this.specialization = specialization;
    }

    public int getExperience() {
        return experience;
    }

    public void setExperience(int experience) {
        this.experience = experience;
    }

    public Department getDepartment() {
        return department;
    }

    public void setDepartment(Department department) {
        this.department = department;
    }

    @Override
    public String toString() {
        return "Doctor{" +
                "staffId=" + staffId +
                ", staffName='" + staffName + '\'' +
                ", age=" + age +
                ", gender='" + gender + '\'' +
                ", phone='" + phone + '\'' +
                ", salary=" + salary +
                ", specialization='" + specialization + '\'' +
                ", experience=" + experience +
                ", department=" + department +
                '}';
    }
}