package com.crimsonlogic.hospitalmanagement.model;


import java.time.LocalDate;
import java.time.LocalTime;

public class Appointment {

	private String appointmentId;
    private LocalDate appointmentDate;
    private LocalTime appointmentTime;
    private Patient patient;
    private Doctor doctor;

    public Appointment() {}

    @Override
    public String toString() {
        return "\nAppointment ID : " + appointmentId +
               "\nDate          : " + appointmentDate +
               "\nTime          : " + appointmentTime +
               "\n\nPatient ID    : " + patient.getPatientId() +
               "\nPatient Name  : " + patient.getPatientName() +
               "\nAge           : " + patient.getAge() +
               "\nGender        : " + patient.getGender() +
               "\nPhone         : " + patient.getPhone() +
               "\n\nDoctor ID     : " + doctor.getStaffId() +
               "\nDoctor Name   : " + doctor.getStaffName();
    }
	public Appointment(String appointmentId2, LocalDate appointmentDate,
                       LocalTime appointmentTime,
                       Patient patient, Doctor doctor) {
        this.appointmentId = appointmentId2;
        this.appointmentDate = appointmentDate;
        this.appointmentTime = appointmentTime;
        this.patient = patient;
        this.doctor = doctor;
    }

    public String getAppointmentId() {
        return appointmentId;
    }

    public void setAppointmentId(String appointmentId) {
        this.appointmentId = appointmentId;
    }

    public LocalDate getAppointmentDate() {
        return appointmentDate;
    }

    public void setAppointmentDate(LocalDate appointmentDate) {
        this.appointmentDate = appointmentDate;
    }

    public LocalTime getAppointmentTime() {
        return appointmentTime;
    }

    public void setAppointmentTime(LocalTime appointmentTime) {
        this.appointmentTime = appointmentTime;
    }

    public Patient getPatient() {
        return patient;
    }

    public void setPatient(Patient patient) {
        this.patient = patient;
    }

    public Doctor getDoctor() {
        return doctor;
    }

    public void setDoctor(Doctor doctor) {
        this.doctor = doctor;
    }
}