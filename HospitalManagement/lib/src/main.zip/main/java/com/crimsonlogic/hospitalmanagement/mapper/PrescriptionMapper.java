package com.crimsonlogic.hospitalmanagement.mapper;

import java.util.List;

import com.crimsonlogic.hospitalmanagement.model.Prescription;

public interface PrescriptionMapper {

    void addPrescription(
            Prescription prescription);

    Prescription getPrescriptionById(
            String prescriptionId);

    List<Prescription> getAllPrescriptions();

    void updatePrescription(
            Prescription prescription);

    void deletePrescription(
            String prescriptionId);
}