package com.crimsonlogic.hospitalmanagement.services;

import java.util.List;

import org.apache.ibatis.session.SqlSession;

import com.crimsonlogic.hospitalmanagement.exceptions.PatientNotFoundException;
import com.crimsonlogic.hospitalmanagement.mapper.PatientMapper;
import com.crimsonlogic.hospitalmanagement.model.Patient;
import com.crimsonlogic.hospitalmanagement.util.MyBatisUtil;

public class PatientService {

    public void addPatient(Patient patient) {

        validatePatient(patient);

        try (SqlSession session = MyBatisUtil.getSqlSession()) {

            PatientMapper mapper =
                    session.getMapper(PatientMapper.class);

            mapper.addPatient(patient);

            session.commit();
        }
    }

    public Patient getPatientById(int patientId) {

        try (SqlSession session = MyBatisUtil.getSqlSession()) {

            PatientMapper mapper =
                    session.getMapper(PatientMapper.class);

            Patient patient =
                    mapper.getPatientById(patientId);

            if (patient == null) {

                throw new PatientNotFoundException(
                        "Patient with ID "
                        + patientId
                        + " not found");
            }

            return patient;
        }
    }

    public List<Patient> getAllPatients() {

        try (SqlSession session = MyBatisUtil.getSqlSession()) {

            PatientMapper mapper =
                    session.getMapper(PatientMapper.class);

            return mapper.getAllPatients();
        }
    }

    public void updatePatient(Patient patient) {

        validatePatient(patient);

        try (SqlSession session = MyBatisUtil.getSqlSession()) {

            PatientMapper mapper =
                    session.getMapper(PatientMapper.class);

            Patient existingPatient =
                    mapper.getPatientById(
                            patient.getPatientId());

            if (existingPatient == null) {

                throw new PatientNotFoundException(
                        "Patient with ID "
                        + patient.getPatientId()
                        + " not found");
            }

            mapper.updatePatient(patient);

            session.commit();
        }
    }

    public void deletePatient(int patientId) {

        try (SqlSession session = MyBatisUtil.getSqlSession()) {

            PatientMapper mapper =
                    session.getMapper(PatientMapper.class);

            Patient patient =
                    mapper.getPatientById(patientId);

            if (patient == null) {

                throw new PatientNotFoundException(
                        "Patient with ID "
                        + patientId
                        + " not found");
            }

            mapper.deletePatient(patientId);

            session.commit();
        }
    }

    private void validatePatient(Patient patient) {

        if (patient == null) {

            throw new IllegalArgumentException(
                    "Patient cannot be null");
        }

        if (patient.getPatientName() == null ||
                patient.getPatientName().trim().isEmpty()) {

            throw new IllegalArgumentException(
                    "Patient name cannot be empty");
        }

        if (!patient.getPatientName()
                .matches("^[A-Za-z ]{2,50}$")) {

            throw new IllegalArgumentException(
                    "Patient name should contain only alphabets and spaces");
        }

        if (patient.getAge() < 1 ||
                patient.getAge() > 120) {

            throw new IllegalArgumentException(
                    "Age should be between 1 and 120");
        }

        if (patient.getGender() == null ||
                !patient.getGender()
                .matches("(?i)Male|Female|Other")) {

            throw new IllegalArgumentException(
                    "Gender must be Male, Female or Other");
        }

        if (patient.getPhone() == null ||
                !patient.getPhone()
                .matches("^[6-9]\\d{9}$")) {

            throw new IllegalArgumentException(
                    "Phone number must be 10 digits and start with 6, 7, 8 or 9");
        }

        if (patient.getAddress() == null) {

            throw new IllegalArgumentException(
                    "Address cannot be null");
        }
    }
}