package com.crimsonlogic.hospitalmanagement.model;

import java.time.LocalDate;

/**
 * Model class representing a Patient Bill.
 *
 */
public class Bill {

    private String billId;

    private Patient patient;

    private double amount;
    private LocalDate billDate;
    private String status;
//constructor
    public Bill() {
    }
//parametarized constructor
    public Bill(String billId, Patient patient,
                double amount, LocalDate billDate,
                String status) {

        this.billId = billId;
        this.patient = patient;
        this.amount = amount;
        this.billDate = billDate;
        this.status = status;
    }

    public String getBillId() {
        return billId;
    }

    public void setBillId(String billId) {
        this.billId = billId;
    }

    public Patient getPatient() {
        return patient;
    }

    public void setPatient(Patient patient) {
        this.patient = patient;
    }

    public double getAmount() {
        return amount;
    }

    public void setAmount(double amount) {
        this.amount = amount;
    }

    public LocalDate getBillDate() {
        return billDate;
    }

    public void setBillDate(LocalDate billDate) {
        this.billDate = billDate;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    @Override
    public String toString() {
        return "Bill [billId=" + billId
                + ", patient=" + patient
                + ", amount=" + amount
                + ", billDate=" + billDate
                + ", status=" + status + "]";
    }
}