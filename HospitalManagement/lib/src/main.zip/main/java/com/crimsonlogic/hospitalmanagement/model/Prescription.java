package com.crimsonlogic.hospitalmanagement.model;

import java.time.LocalDate;

public class Prescription {

	private String prescriptionId;

    private Patient patient;
    private Doctor doctor;
    private Medicine medicine;

    private String dosage;
    private String instructions;

    private LocalDate prescriptionDate;

    public Prescription() {
    }

    public Prescription(
            String prescriptionId,
            Patient patient,
            Doctor doctor,
            Medicine medicine,
            String dosage,
            String instructions,
            LocalDate prescriptionDate) {

        this.prescriptionId = prescriptionId;
        this.patient = patient;
        this.doctor = doctor;
        this.medicine = medicine;
        this.dosage = dosage;
        this.instructions = instructions;
        this.prescriptionDate = prescriptionDate;
    }

    public String getPrescriptionId() {
        return prescriptionId;
    }

    public void setPrescriptionId(
            String prescriptionId) {
        this.prescriptionId = prescriptionId;
    }

    public Patient getPatient() {
        return patient;
    }

    public void setPatient(
            Patient patient) {
        this.patient = patient;
    }

    public Doctor getDoctor() {
        return doctor;
    }

    public void setDoctor(
            Doctor doctor) {
        this.doctor = doctor;
    }

    public Medicine getMedicine() {
        return medicine;
    }

    public void setMedicine(
            Medicine medicine) {
        this.medicine = medicine;
    }

    public String getDosage() {
        return dosage;
    }

    public void setDosage(
            String dosage) {
        this.dosage = dosage;
    }

    public String getInstructions() {
        return instructions;
    }

    public void setInstructions(
            String instructions) {
        this.instructions = instructions;
    }

    public LocalDate getPrescriptionDate() {
        return prescriptionDate;
    }

    public void setPrescriptionDate(
            LocalDate prescriptionDate) {
        this.prescriptionDate = prescriptionDate;
    }

    @Override
    public String toString() {

        return "Prescription [prescriptionId="
                + prescriptionId
                + ", patient="
                + patient.getPatientName()
                + ", doctor="
                + doctor.getStaffName()
                + ", medicine="
                + medicine.getMedicineName()
                + ", dosage="
                + dosage
                + ", instructions="
                + instructions
                + ", prescriptionDate="
                + prescriptionDate
                + "]";
    }
}