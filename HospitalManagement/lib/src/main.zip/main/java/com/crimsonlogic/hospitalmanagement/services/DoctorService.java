package com.crimsonlogic.hospitalmanagement.services;

import java.util.List;

import org.apache.ibatis.session.SqlSession;

import com.crimsonlogic.hospitalmanagement.exceptions.DoctorNotFoundException;
import com.crimsonlogic.hospitalmanagement.mapper.DoctorMapper;
import com.crimsonlogic.hospitalmanagement.model.Doctor;
import com.crimsonlogic.hospitalmanagement.util.MyBatisUtil;

public class DoctorService {

    public void addDoctor(Doctor doctor) {

        validateDoctor(doctor);

        try(SqlSession session = MyBatisUtil.getSqlSession()) {

            DoctorMapper mapper =
                    session.getMapper(DoctorMapper.class);

            mapper.addDoctor(doctor);

            session.commit();
        }
    }

    public Doctor getDoctorById(int staffId) {

        try(SqlSession session = MyBatisUtil.getSqlSession()) {

            DoctorMapper mapper =
                    session.getMapper(DoctorMapper.class);

            Doctor doctor =
                    mapper.getDoctorById(staffId);

            if(doctor == null) {

                throw new DoctorNotFoundException(
                        "Doctor with ID "
                        + staffId
                        + " not found");
            }

            return doctor;
        }
    }

    public List<Doctor> getAllDoctors() {

        try(SqlSession session = MyBatisUtil.getSqlSession()) {

            DoctorMapper mapper =
                    session.getMapper(DoctorMapper.class);

            return mapper.getAllDoctors();
        }
    }

    public void updateDoctor(Doctor doctor) {

        validateDoctor(doctor);

        try(SqlSession session = MyBatisUtil.getSqlSession()) {

            DoctorMapper mapper =
                    session.getMapper(DoctorMapper.class);

            if(mapper.getDoctorById(
                    doctor.getStaffId()) == null) {

                throw new DoctorNotFoundException(
                        "Doctor with ID "
                        + doctor.getStaffId()
                        + " not found");
            }

            mapper.updateDoctor(doctor);

            session.commit();
        }
    }

    public void deleteDoctor(int staffId) {

        try(SqlSession session = MyBatisUtil.getSqlSession()) {

            DoctorMapper mapper =
                    session.getMapper(DoctorMapper.class);

            if(mapper.getDoctorById(staffId)
                    == null) {

                throw new DoctorNotFoundException(
                        "Doctor with ID "
                        + staffId
                        + " not found");
            }

            mapper.deleteDoctor(staffId);

            session.commit();
        }
    }
    private void validateDoctor(Doctor doctor) {

        if (doctor == null) {
            throw new IllegalArgumentException(
                    "Doctor object cannot be null");
        }

        if (doctor.getStaffName() == null ||
                doctor.getStaffName().trim().isEmpty()) {

            throw new IllegalArgumentException(
                    "Doctor name cannot be empty");
        }

        if (!doctor.getStaffName()
                .matches("^[A-Za-z ]{3,50}$")) {

            throw new IllegalArgumentException(
                    "Doctor name should contain only alphabets and spaces (3-50 characters)");
        }

        if (doctor.getAge() < 1 ||
                doctor.getAge() > 120) {

            throw new IllegalArgumentException(
                    "Age should be between 1 and 120");
        }

        if (doctor.getGender() == null ||
                !doctor.getGender()
                .matches("(?i)Male|Female|Other")) {

            throw new IllegalArgumentException(
                    "Gender must be Male, Female or Other");
        }

        if (doctor.getPhone() == null ||
                !doctor.getPhone()
                .matches("^[6-9]\\d{9}$")) {

            throw new IllegalArgumentException(
                    "Phone number must be 10 digits and start with 6,7,8 or 9");
        }

        if (doctor.getSalary() <= 0) {

            throw new IllegalArgumentException(
                    "Salary must be greater than zero");
        }

        if (doctor.getExperience() < 0 ||
                doctor.getExperience() > 60) {

            throw new IllegalArgumentException(
                    "Experience should be between 0 and 60 years");
        }

        if (doctor.getSpecialization() == null ||
                doctor.getSpecialization().trim().isEmpty()) {

            throw new IllegalArgumentException(
                    "Specialization cannot be empty");
        }

        if (!doctor.getSpecialization()
                .matches("^[A-Za-z ]{3,50}$")) {

            throw new IllegalArgumentException(
                    "Specialization should contain only alphabets");
        }

        if (doctor.getDepartment() == null) {

            throw new IllegalArgumentException(
                    "Department cannot be null");
        }
    }

    
    }
