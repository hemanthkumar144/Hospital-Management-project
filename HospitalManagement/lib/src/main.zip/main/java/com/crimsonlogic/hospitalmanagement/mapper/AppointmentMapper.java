package com.crimsonlogic.hospitalmanagement.mapper;

import java.util.List;

import com.crimsonlogic.hospitalmanagement.model.Appointment;

public interface AppointmentMapper {

    void addAppointment(Appointment appointment);

    Appointment getAppointmentById(String appointmentId);

    List<Appointment> getAllAppointments();

    void updateAppointment(Appointment appointment);

    void deleteAppointment(String appointmentId);
    Integer getAppointmentNumber();
}