package com.crimsonlogic.hospitalmanagement.menu;

import java.util.List;
import java.util.Scanner;

import com.crimsonlogic.hospitalmanagement.model.Department;
import com.crimsonlogic.hospitalmanagement.services.DepartmentService;

public class DepartmentMenu {

    public static void showMenu(Scanner sc) {

        DepartmentService service = new DepartmentService();

        while (true) {

            System.out.println("\n========== DEPARTMENT MANAGEMENT ==========");
            System.out.println("1. Add Department");
            System.out.println("2. View Department By ID");
            System.out.println("3. View All Departments");
            System.out.println("4. Update Department");
            System.out.println("5. Delete Department");
            System.out.println("6. Back");

            System.out.print("Enter Choice : ");
            int choice = sc.nextInt();

            switch (choice) {

                case 1:

                    System.out.print("Enter Department ID : ");
                    String id = sc.next();
                   

                    System.out.print("Enter Department Name : ");
                    String name = sc.nextLine();

                    System.out.print("Enter Location : ");
                    String location = sc.nextLine();

                    Department dept =
                            new Department(id, name, location);

                    service.addDepartment(dept);

                    System.out.println("Department Added Successfully");
                    break;

                case 2:

                    System.out.print("Enter Department ID : ");
                    int deptId = sc.nextInt();

                    Department department =
                            service.getDepartmentById(deptId);

                    if (department != null) {
                        System.out.println(department);
                    } else {
                        System.out.println("Department Not Found");
                    }

                    break;

                case 3:

                    List<Department> departments =
                            service.getAllDepartments();

                    System.out.printf("%-10s %-25s %-20s%n",
                            "ID",
                            "Department Name",
                            "Location");

                    System.out.println("--------------------------------------------------------");

                    for (Department d : departments) {

                        System.out.printf("%-10d %-25s %-20s%n",
                                d.getDepartmentId(),
                                d.getDepartmentName(),
                                d.getLocation());
                    }

                    break;

                case 4:

                    System.out.print("Enter Department ID : ");
                    String updateId = sc.next();
                    sc.nextLine();

                    System.out.print("Enter New Department Name : ");
                    String updateName = sc.nextLine();

                    System.out.print("Enter New Location : ");
                    String updateLocation = sc.nextLine();

                    Department updateDept =
                            new Department(updateId,
                                    updateName,
                                    updateLocation);

                    service.updateDepartment(updateDept);

                    System.out.println("Department Updated Successfully");
                    break;

                case 5:

                    System.out.print("Enter Department ID : ");
                    int deleteId = sc.nextInt();

                    service.deleteDepartment(deleteId);

                    System.out.println("Department Deleted Successfully");
                    break;

                case 6:
                    return;

                default:
                    System.out.println("Invalid Choice");
            }
        }
    }
}