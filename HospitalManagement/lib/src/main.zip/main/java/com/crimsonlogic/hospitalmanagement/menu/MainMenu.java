package com.crimsonlogic.hospitalmanagement.menu;

import java.util.Scanner;

public class MainMenu {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        while (true) {

            System.out.println("\n========================================");
            System.out.println("   HOSPITAL MANAGEMENT SYSTEM");
            System.out.println("========================================");
            System.out.println("1. Department Management");
            System.out.println("2. Doctor Management");
            System.out.println("3. Patient Management");
            System.out.println("4. Medicine Management");
            System.out.println("5. Appointment Management");
            System.out.println("6. Exit");

            System.out.print("Enter Choice : ");
            int choice = sc.nextInt();

            switch (choice) {

                case 1:
                    DepartmentMenu.showMenu(sc);
                    break;

                case 2:
                    DoctorMenu.showMenu(sc);
                    break;

                case 3:
                    PatientMenu.showMenu(sc);
                    break;

                case 4:
                    MedicineMenu.showMenu(sc);
                    break;

                case 5:
                    AppointmentMenu.showMenu(sc);
                    break;

                case 6:
                    System.out.println("Thank You...");
                    sc.close();
                    System.exit(0);

                default:
                    System.out.println("Invalid Choice!");
            }
        }
    }
}