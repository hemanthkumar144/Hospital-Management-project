package com.crimsonlogic.hospitalmanagement.model;

/**
 * Model class representing a Hospital Bed.
 *
 *
 */
public class Bed {

    private String bedId;
    private String wardName;
    private String bedType;
    private String availability;

    private Patient patient;

    public Bed() {
    }

    public Bed(String bedId, String wardName,
               String bedType, String availability,
               Patient patient) {

        this.bedId = bedId;
        this.wardName = wardName;
        this.bedType = bedType;
        this.availability = availability;
        this.patient = patient;
    }

    public String getBedId() {
        return bedId;
    }

    public void setBedId(String bedId) {
        this.bedId = bedId;
    }

    public String getWardName() {
        return wardName;
    }

    public void setWardName(String wardName) {
        this.wardName = wardName;
    }

    public String getBedType() {
        return bedType;
    }

    public void setBedType(String bedType) {
        this.bedType = bedType;
    }

    public String getAvailability() {
        return availability;
    }

    public void setAvailability(String availability) {
        this.availability = availability;
    }

    public Patient getPatient() {
        return patient;
    }

    public void setPatient(Patient patient) {
        this.patient = patient;
    }

    @Override
    public String toString() {
        return "Bed [bedId=" + bedId
                + ", wardName=" + wardName
                + ", bedType=" + bedType
                + ", availability=" + availability
                + ", patient=" + patient + "]";
    }
}