package com.crimsonlogic.hospitalmanagement.mapper;
import java.util.List;

import com.crimsonlogic.hospitalmanagement.model.Department;

public interface DepartmentMapper {

    void addDepartment(Department department);

    Department getDepartmentById(String departmentId);

    List<Department> getAllDepartments();

    void updateDepartment(Department department);

    void deleteDepartment(String departmentId);
    Integer getMaxDepartmentNumber();
}