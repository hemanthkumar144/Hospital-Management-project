import com.crimsonlogic.hospitalmanagement.model.Department;
import com.crimsonlogic.hospitalmanagement.services.DepartmentService;
import com.crimsonlogic.hospitalmanagement.util.MenuUtil;

public class Main {

    public static void main(String[] args) {

       MenuUtil menu=new MenuUtil();
       menu.departmentMenu();
    }
}